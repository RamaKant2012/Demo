package com.example.demo;

import com.example.other.Probe;

public class CaseDefinition {
    public static void executeCases(Probe probe, String commands) {
        for (char command : commands.toCharArray()) {
            switch (command) {
                case 'F': probe.moveForward(); break;
                case 'B': probe.moveBackward(); break;
                case 'L': probe.turnLeft(); break;
                case 'R': probe.turnRight(); break;
                default: throw new IllegalArgumentException("Unknown command: " + command);
            }
        }
    }
}
