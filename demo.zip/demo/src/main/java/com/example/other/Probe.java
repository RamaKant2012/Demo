package com.example.other;

import com.example.constants.Direction;

import java.util.ArrayList;
import java.util.List;

public class Probe {
    private int x;
    private int y;
    private Direction direction;
    private GridEx gridEx;
    private List<String> visitedCoordinates;

    public Probe(int x, int y, Direction direction, GridEx gridEx) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.gridEx = gridEx;
        this.visitedCoordinates = new ArrayList<>();
        addVisitedCoordinate();
    }

    public void moveForward() {
        int newX = x + direction.getDeltaX();
        int newY = y + direction.getDeltaY();
        if (gridEx.checkWithinBounds(newX, newY) && !gridEx.checkForAnyObstacles(newX, newY)) {
            x = newX;
            y = newY;
            addVisitedCoordinate();
        }
    }

    public void moveBackward() {
        int newX = x - direction.getDeltaX();
        int newY = y - direction.getDeltaY();
        if (gridEx.checkWithinBounds(newX, newY) && !gridEx.checkForAnyObstacles(newX, newY)) {
            x = newX;
            y = newY;
            addVisitedCoordinate();
        }
    }

    public void turnLeft() {
        direction = direction.turnLeft();
    }

    public void turnRight() {
        direction = direction.turnRight();
    }

    public List<String> getVisitedCoordinates() {
        return visitedCoordinates;
    }

    private void addVisitedCoordinate() {
        visitedCoordinates.add("(" + x + ", " + y + ")");
    }
}

