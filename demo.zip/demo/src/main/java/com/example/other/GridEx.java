package com.example.other;

public class GridEx {
    private int width;
    private int height;
    private boolean[][] checkAnyObstacles;

    public GridEx(int width, int height) {
        this.width = width;
        this.height = height;
        this.checkAnyObstacles = new boolean[width][height];
    }

    public boolean checkForAnyObstacles(int x, int y) {
        return checkAnyObstacles[x][y];
    }

    public void setCheckAnyObstacles(int x, int y) {
        this.checkAnyObstacles[x][y] = true;
    }

    public boolean checkWithinBounds(int x, int y) {
        return x >= 0 && x < width && y >= 0 && y < height;
    }
}

