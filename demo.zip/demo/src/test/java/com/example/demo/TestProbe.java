package com.example.demo;



import com.example.constants.Direction;
import com.example.other.GridEx;
import com.example.other.Probe;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



public class TestProbe {
    @Test
    public void testMovement() {
        GridEx gridEx = new GridEx(5, 5);
        Probe probe = new Probe(2, 2, Direction.NORTH, gridEx);

        CaseDefinition.executeCases(probe, "FFLFF");

        Assertions.assertEquals("(2, 2), (2, 3), (2, 4), (1, 4), (0, 4)", String.join(", ", probe.getVisitedCoordinates()));

    }

    @Test
    public void testObstacle() {
        GridEx gridEx = new GridEx(5, 5);
        gridEx.setCheckAnyObstacles(2, 3);
        Probe probe = new Probe(2, 2, Direction.NORTH, gridEx);

        CaseDefinition.executeCases(probe, "FFRFF");

        Assertions.assertEquals("(2, 2), (3, 2), (4, 2)", String.join(", ", probe.getVisitedCoordinates()));
    }

    @Test
    public void testBoundary() {
        GridEx grid = new GridEx(3, 3);
        Probe probe = new Probe(1, 1, Direction.NORTH, grid);

        CaseDefinition.executeCases(probe, "FFFFFFFF");

        Assertions.assertEquals("(1, 1), (1, 2)", String.join(", ", probe.getVisitedCoordinates()));
    }
}
